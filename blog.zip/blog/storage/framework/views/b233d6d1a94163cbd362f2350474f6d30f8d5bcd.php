<?php $__env->startSection('header'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <p>Name: <strong><?php echo e($teams->club); ?></strong></p>


    <ul>
        <?php $__currentLoopData = $players; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $player): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><a href="<?php echo e(route('players.show', $player->id)); ?>"><?php echo e($player->voornaam . " " . $player->achternaam); ?></a></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>

    <a href="<?php echo e(route('teams.edit', $teams->id)); ?>" class="btn btn-warning">Edit Club</a>


    <form action="<?php echo e(route('teams.destroy', $teams->id )); ?>" method="POST" class="row g-3">
        <?php echo csrf_field(); ?>
        <?php echo method_field('DELETE'); ?>

        <div class="col-6" style="margin: 0.3% 0">
            <input type="submit" value="DELETE" class="btn btn-danger">
        </div>
    </form>


<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\blog\resources\views/teams/show.blade.php ENDPATH**/ ?>