<?php $__env->startSection('header'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <ul class="list-group">
        <?php $__currentLoopData = $players; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $player): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li class="list-group-item list-group-item-light" style="margin: 0.1%">
                <a href="<?php echo e(route('players.show', $player->id)); ?>"><?php echo e($player->voornaam . " " . $player->achternaam); ?></a>
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>

    <div style="display: flex;justify-content: flex-end; margin: 1.1%">
        <a href="<?php echo e(route('players.create')); ?>" class="btn btn-primary">create new player</a>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\blog\resources\views/players/index.blade.php ENDPATH**/ ?>