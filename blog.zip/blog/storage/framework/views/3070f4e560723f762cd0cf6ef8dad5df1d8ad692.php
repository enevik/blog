<?php $__env->startSection('header'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <p>name: <strong><?php echo e($players->voornaam); ?> <?php echo e($players->achternaam); ?></strong></p>
    <a href="<?php echo e(route('teams.show', $players->teams->id)); ?>" class="btn btn-primary"> <strong><?php echo e($players->teams->club); ?></strong></a>

    <a href="<?php echo e(route('players.edit', $players->id)); ?>" class="btn btn-warning">Edit player</a>

    <form action="<?php echo e(route('players.destroy', $players->id )); ?>" method="POST" class="row g-3">
        <?php echo csrf_field(); ?>
        <?php echo method_field('DELETE'); ?>

        <div class="col-6" style="margin: 0.3% 0">
            <input type="submit" value="DELETE" class="btn btn-danger">
        </div>
    </form>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\blog\resources\views/players/show.blade.php ENDPATH**/ ?>