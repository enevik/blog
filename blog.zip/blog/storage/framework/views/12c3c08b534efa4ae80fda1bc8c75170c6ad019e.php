<?php $__env->startSection('header'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <form action="<?php echo e(route('players.update', $player->id)); ?>" method="POST" class="row g-3" style="margin: 0 0.5%">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="col-md-12">
            <label class="form-label">Firstname</label>
            <input type="text" name="firstname" class="form-control" placeholder="<?php echo e($player->voornaam); ?>">
        </div>
        <div class="col-md-12">
            <label class="form-label">Lastname</label>
            <input type="text" name="lastname" class="form-control" placeholder="<?php echo e($player->achternaam); ?>">
        </div>
        <div class="col-md-12">
            <label class="form-label">Select team</label>
            <select name="team_id" class="form-select form-select-lg col-md-12">
                <?php $__currentLoopData = $teams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $team): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($team->id); ?>"><?php echo e($team->club); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        </select>
        <div class="col-md-12" style="display: flex;justify-content: flex-end;margin:.3% 0">
            <input type="submit" class="btn btn-primary" value="Edit player">
        </div>
    </form>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\blog\resources\views/players/edit.blade.php ENDPATH**/ ?>