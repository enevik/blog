<?php $__env->startSection('header'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <form action="<?php echo e(route('players.store')); ?>" method="POST" class="row g-3" style="margin: 0.3% 0" >
        <?php echo csrf_field(); ?>
        <div class="col-md-12">
            <label class="form-label">Firstname</label>
            <input type="text" name="firstname" class="form-control">
        </div>

        <div class="col-md-12">
            <label class="form-label">Lastname</label>
            <input type="text" name="lastname" class="form-control">
        </div>
        <div class="col-md-12">
            <label class="form-label">Select team</label>
            <select name="team_id" class="form-select form-select-lg col-md-12">
                <?php $__currentLoopData = $players; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $player): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($player->team_id); ?>"><?php echo e($player->teams->club); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <div class="col-12" style="margin-top: 0.4%">
            <input type="submit" value="create new player" class="btn btn-primary">
        </div>
    </form>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\blog\resources\views/players/create.blade.php ENDPATH**/ ?>