<?php $__env->startSection('header'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <form action="<?php echo e(route('teams.update', $teams->id)); ?>" method="POST" class="row g-3" style="margin: 0 0.5%">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="col-md-6">
            <label for="" class="form-label">Enter new clubname</label>
            <input type="text" name="club" class="form-control">
        </div>

        <div class="col-12" style="margin: 0.4% 0">
            <input type="submit" value="edit" class="btn btn-warning">
        </div>
    </form>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\blog\resources\views/teams/edit.blade.php ENDPATH**/ ?>